
import{Link,BrowserRouter as Router,Route,Switch} from 'react-router-dom';
import SignUp from './Components/SignUp';
import Login from'./Form Components/Fields/Login';
import Home from './Form Components/Home';
import Dashboard from './Form Components/Dashboard';

function App() {
  return (
    <>
   
    <Router>


	<ul>
 
	<li style={{display:"inline-block",padding: "0px 10px"}}>

  <Link to ="/">Home</Link>
 
    </li>
   
	<li style={{display:"inline-block",padding: "0px 10px"}}>
    <Link to ="/Signup">Signup</Link>
		
	</li>
  <li style={{display:"inline-block",padding: "0px 10px"}}>
  <Link to="/login">Login</Link>
  </li>
  <li style={{display:"inline-block",padding: "0px 10px"}}>
  <Link to="/dashboard">Dashboard</Link>
  </li>

	</ul>


<Switch>
  <Route  exact path ="/" component={Home}></Route>
<Route  path='/login' component={Login}></Route>
<Route  path='/signup' component={SignUp}></Route>
<Route path ='/dashboard' component={Dashboard}></Route>
  </Switch>


</Router>



 

    </>

   
  );
}

export default App;
