import { Link } from '@material-ui/core';
import Form from '../../Form Components/login';
import fields from '../fields';


const Login1=()=>{

<div className="Container">


 
      {/* <Form className="form"
        initialValues={{}}
        onSubmit={(payload) => {
          console.log("payload", payload);
          alert("ON SUBMIT");
        }}
        btnText={"Login"}
        fields={fields}
      /> */}
      <h1>Hello</h1>
    </div>

}
export default Login1;