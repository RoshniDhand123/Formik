import React from "react";
import { Formik, Form, Field } from "formik";
import { Button, Grid } from "@material-ui/core";
import {createSchema1} from"../Form Components/Fields/loginValidation";
import { useHistory } from "react-router";

const FormComponent=(props)=>{
  const history = useHistory();
  const login=()=>{
    history.push('signup');
  }

  const schema = createSchema1(props.fields)

   const renderField = (props) => {
        return (
          <Grid item xs={props.grid || 12}>
            <Field key={props.name} {...props} />
          </Grid>
        );
      };

  const renderForm = ({ handleSubmit }) => {
        const { fields, renderCustomSubmit, btnText,btn } = props;
        return (
          // onSubmit={handleSubmit}
          <Form>
            <>
              <Grid container spacing={2}>
                {fields.map(renderField)}
              </Grid>
              {renderCustomSubmit || (
                <Button variant="contained" type="submit">
                  {btnText}
                </Button>
                
              )}
                <Button  variant ="contained" onClick={login}>{btn}</Button>
            </>
          </Form>
        );
      };


      return (
     
        <Formik
          initialValues={props.initialValues}
          onSubmit={props.onSubmit}
         validationSchema={schema}
        >
          {renderForm}
        </Formik>
     
    );

      
}
export default FormComponent;