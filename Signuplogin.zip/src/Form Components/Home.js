const Home=()=>{
    <h1>
        Hello User
    </h1>
}
 export default Home();